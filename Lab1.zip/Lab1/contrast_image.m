function v = contrast_image(img, alpha, beta)
  v = alpha*img + beta;
endfunction
