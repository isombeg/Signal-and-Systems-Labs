function y = unitpulse(x)
  % Value will equal 1 when element in x is 0
  y = x == 0;
endfunction